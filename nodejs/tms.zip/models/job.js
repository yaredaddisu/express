const pool = require('../db');

const createJob = async (job) => {
  const { customerId, serviceType, location, description, technicianId } = job;
  const sql = `INSERT INTO jobs (customer_id, service_type, location, description, technician_id, status) VALUES (?, ?, ?, ?, ?, 'pending')`;
  const [result] = await pool.query(sql, [customerId, serviceType, location, description, technicianId]);
  return result.insertId;
};

const getJobById = async (id) => {
  const sql = `SELECT * FROM jobs WHERE id = ?`;
  const [rows] = await pool.query(sql, [id]);
  return rows[0];
};

// Additional methods like updateJob, assignTechnician, updateJobStatus, etc.

module.exports = {
  createJob,
  getJobById,
};
