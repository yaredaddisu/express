const TelegramBot = require('node-telegram-bot-api');
const dotenv = require('dotenv');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const ExcelJS = require('exceljs');
const { createTechnician, getTechnicianById,getTechnicianByChatId ,getAllTechnicians,updateTechnicianAttribute,updateTechnicianStatus} = require('./models/technician');
const { createJob, getJobById } = require('./models/job');
const { createAdmin, getAdminById,getAdminByChatId ,getAllAdmins,updateAdminAttribute,updateAdminStatus} = require('./models/admin');
const { createMachine, getMachineById,getMachineByChatId ,deleteMachineById,getAllMachines,updateMachineAttribute,updateMachineStatus} = require('./models/machine');
const { createCompany, getCompanyById,getCompanyByChatId ,deleteCompanyById,getAllCompanys,updateCompanyAttribute,updateCompanyStatus} = require('./models/company');
const { createLocation, getLocationById,getLocationByChatId ,deleteLocationById,getAllLocations,updateLocationAttribute,updateLocationStatus} = require('./models/location');

dotenv.config();

const bot = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: true });
const adminId = 7245407632
// Define the keyboard buttons
const keyboard = [
    ['Add Machine', 'View Technicians'], // First row
    ['View Machines', 'View Admins'], // Second row
    ['Add Company', 'View Companies'],
    ['Add Location', 'View Locations'],
    
  ];
  
  // Create the reply markup for the keyboard
  const replyMarkup = {
    keyboard: keyboard,
    resize_keyboard: true, // Optional: resize keyboard to fit the screen
    one_time_keyboard: true // Optional: hide the keyboard after use
  };
  const keyboardByAdmin = [
    ['Add Technician', 'View Technicians'], // First row
    ['Button 3', 'Button 4'], // Second row
    ['Button 5'] // Third row (can have a single button or more)
  ];
  
  // Create the reply markup for the keyboard
  const replyAdminMarkup = {
    keyboard: keyboardByAdmin,
    resize_keyboard: true, // Optional: resize keyboard to fit the screen
    one_time_keyboard: true // Optional: hide the keyboard after use
  };

  function createCancelKeyboard() {
    return {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Cancel', callback_data: 'cancel_action' }]
        ]
      }
    };
  }
  bot.on('callback_query', (callbackQuery) => {
    const messageId = callbackQuery.message.message_id;
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
  
    if (data === 'cancel_action') {
      bot.sendMessage(chatId, 'Operation cancelled.');
        technicianRegistration[chatId] = null;
      // Optionally, delete the cancel button message
      bot.deleteMessage(chatId, messageId).catch((error) => console.log("Message already deleted."));
      
      // Perform any other cleanup operations here
    }
  });
// Store registration data
const userRegistration = {};

async function handleTechnicianRegistration(chatId) {
  try {
    const technician = await getTechnicianByChatId(chatId);
    if (technician) {
      const previewMessage = `
      👷‍♂️ *Technician Preview* 👷‍♂️
      First Name: ${technician.firstName}
      Last Name: ${technician.lastName}
      Phone: ${technician.phone}
      Email: ${technician.email}
      Skills: ${technician.skills}
      Experience: ${technician.experience} years
      `;
      const options = {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
   
                [ { text: 'Close', callback_data: 'closeProfile' } ],
            ],
        },
    };
  
       await bot.sendMessage(chatId, previewMessage,options);
      userRegistration[chatId] = null;
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error fetching technician:', error);
    await bot.sendMessage(chatId, 'There was an error checking your registration status.');
    return false;
  }
}
async function handleAdminRegistration(chatId) {
  try {
    const admin = await getAdminByChatId(chatId);
    if (admin) {
      await bot.sendMessage(chatId, `Welcome back. ${admin.firstName} ${admin.lastName}`);
      userRegistration[chatId] = null;
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error fetching technician:', error);
    await bot.sendMessage(chatId, 'There was an error checking your registration status.');
    return false;
  }
}
// Command to start the registration process
bot.onText(/\/register/, async (msg) => {
  const chatId = msg.chat.id;
  const firstName = msg.from.first_name;
  const lastName = msg.from.last_name || "Null";
  const username = msg.from.username;

  const isAlreadyRegistered = await handleTechnicianRegistration(chatId);

  if (!isAlreadyRegistered) {
    const keyboard = {
      reply_markup: {
        keyboard: [
          [
            {
              text: 'Share Contact',
              request_contact: true
            }
          ]
        ],
        one_time_keyboard: true,
        resize_keyboard: true
      }
    };

    // Initialize registration data
    userRegistration[chatId] = {
      firstName,
      lastName,
      phone: null,
      email: "email",
      skills: "Null",
      experience: "Null",
      status: "0",
      chatId,
      username,
      previewMessageId: null
    };

    // Notify user to share contact
    await bot.sendMessage(chatId, 'Please share your phone number:', keyboard);
  }
});

// Handle received contact information
bot.on('contact', async (msg) => {
  const chatId = msg.chat.id;
  const contact = msg.contact;

  if (contact) {
    const phoneNumber = contact.phone_number;

    // Update registration data with phone number
    if (userRegistration[chatId]) {
      userRegistration[chatId].phone = phoneNumber;

      // Remove the custom keyboard
      await bot.sendMessage(chatId, 'Thank you for sharing your contact. We are processing your registration...', {
        reply_markup: {
          remove_keyboard: true
        }
      });

      // Check if username is set
      if (!userRegistration[chatId].username) {
        await bot.sendMessage(chatId, `Hello, ${userRegistration[chatId].firstName}! It looks like you don't have a Telegram username set. Please set one in your Telegram settings to continue.`);
      } else {
        // Simulate creating technician and handle response
        try {
          const technicianId = await createTechnician(userRegistration[chatId]);
          const messageId = userRegistration[chatId].previewMessageId;

          // await bot.sendMessage(chatId, `Technician added with ID: ${technicianId}`);

          if (messageId) {
            await bot.deleteMessage(chatId, messageId);
          }


          // Confirm registration
          await bot.sendMessage(chatId, `Thank you for registering! Name: ${userRegistration[chatId].firstName}, Username: @${userRegistration[chatId].username}`).then(()=>{
            delete userRegistration[chatId]; // Clear registration data

          });
        } catch (error) {
          console.error('Error creating technician:', error);
          await bot.sendMessage(chatId, 'There was an error processing your registration.');
        }
      }
    }
  } else {
    await bot.sendMessage(chatId, 'It looks like you did not share a contact. Please try again.');
  }
});

// Start command
bot.onText(/\/start/,async (msg) => {
  const chatId = msg.chat.id;

  // Check if the chat ID is the admin ID
  if (chatId === adminId) {
    bot.sendMessage(msg.chat.id, "Welcome to the Technician Management System! Use /addtechnician to add a technician.", {
      reply_markup: replyMarkup
    });
  } else {
    const isAlreadyRegistered = await handleTechnicianRegistration(chatId);
    if(!isAlreadyRegistered){
      bot.sendMessage(chatId, 'Welcome to the Technician Management System! Use /register to start the registration process.');
    }
  }   
});

// Add Technician Command
let technicianRegistration = {}; // Temporary storage for technician details

bot.onText(/Add Technician/, (msg) => {
    const chatId = msg.chat.id;

    technicianRegistration[chatId] = {
        step: 'first_name'
    };
    bot.sendMessage(chatId, "Please enter the technician's name:");
});

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
  
    if (!technicianRegistration[chatId] || technicianRegistration[chatId].isEditing) return;
  
    const registration = technicianRegistration[chatId];
  
    switch (registration.step) {
        case 'first_name':
            registration.firstName = text;
            registration.step = 'last_name';
            bot.sendMessage(chatId, 'Please enter your lastname:', createCancelKeyboard());
            break;
          case 'last_name':
            registration.lastName = text;
            registration.step = 'phone';
            bot.sendMessage(chatId, 'Please enter the technician\'s phone number:', createCancelKeyboard());
            break;
        case 'phone':
            registration.phone = text;
            registration.step = 'email';
            bot.sendMessage(chatId, 'Please enter the technician\'s email address:', createCancelKeyboard());
            break;
        
        case 'email':
            registration.email = text;
            registration.step = 'skills';
            bot.sendMessage(chatId, 'Please enter the technician\'s skills (comma-separated):', createCancelKeyboard());
            break;
        
        case 'skills':
            registration.skills = text;
            registration.step = 'experience';
            bot.sendMessage(chatId, 'Please enter the technician\'s experience in years:', createCancelKeyboard());
            break;
        
        case 'experience':
            registration.experience = text;
            registration.status = 1;
            registration.chatId = chatId

            registration.step = 'preview';
            displayRegistrationDetails(chatId);
            break;
  
        default:
            bot.sendMessage(chatId, 'Registration step not recognized. Please start over.', createCancelKeyboard());
            break;
    }
});
  
async function displayRegistrationDetails(chatId) {
    const registration = technicianRegistration[chatId];
    // console.log(registration)
    const previewMessage = `
    👷‍♂️ *Technician Preview* 👷‍♂️
    First Name: ${registration.firstName}
    Last Name: ${registration.lastName}
    Phone: ${registration.phone}
    Email: ${registration.email}
    Skills: ${registration.skills}
    Experience: ${registration.experience} years
    `;
  
    const options = {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Edit First Name', callback_data: 'edit_firstName' },{ text: 'Edit Last Name', callback_data: 'edit_lastName' }],
                [{ text: 'Edit Email', callback_data: 'edit_email' },{ text: 'Edit Skills', callback_data: 'edit_skills' }],
                [{ text: 'Edit Phone', callback_data: 'edit_phone' },{ text: 'Edit Experience', callback_data: 'edit_experience' }],
                [{ text: 'Confirm', callback_data: 'confirm' },{ text: 'Close', callback_data: 'close' } ],
            ],
        },
    };
  
    // Store the message ID for future editing
    if (!registration.previewMessageId) {
        const sentMessage = await bot.sendMessage(chatId, previewMessage, options);
        registration.previewMessageId = sentMessage.message_id;
    } else {
        await bot.editMessageText(previewMessage, {
            chat_id: chatId,
            message_id: registration.previewMessageId,
            parse_mode: 'Markdown',
            reply_markup: options.reply_markup
        });
    }
}
  
bot.on('callback_query', (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if (data.startsWith('edit_')) {
        const field = data.split('_')[1];
        const fieldMap = {
            firstName: "firstName",
            lastName:"lastName",
            phone: "Phone",
            email: "Email",
            skills: "Skills",
            experience: "Experience",
            status: "Status",

        };
      
        technicianRegistration[chatId].isEditing = true;
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[field]}:`);

        bot.once('message', (msg) => {
            const text = msg.text;
            technicianRegistration[chatId][field] = text;
            technicianRegistration[chatId].isEditing = false;
            displayRegistrationDetails(chatId); // Re-display the preview after editing
        });

    } else if (data === 'confirm') {
        createTechnician(technicianRegistration[chatId]).then((technicianId) => {
            const messageId = technicianRegistration[chatId].previewMessageId;
            console.log(technicianRegistration[chatId])

            bot.sendMessage(chatId, `Technician added with ID: ${technicianId}`).then(()=>{
                bot.deleteMessage(chatId, messageId);
            });
            delete technicianRegistration[chatId]; // Clear registration data
        });
    }
    else if (data === 'close') {
    
       bot.deleteMessage(chatId, messageId).then(()=>{
           delete technicianRegistration[chatId];
       });
      
  }
});

// Assign Job Command
bot.onText(/\/assignjob/, (msg) => {
  bot.sendMessage(msg.chat.id, "Please send job details in the following format:\nCustomerID, ServiceType, Location, Description, TechnicianID");

  bot.once('message', async (response) => {
    const [customerId, serviceType, location, description, technicianId] = response.text.split(',');
    const jobId = await createJob({ customerId, serviceType, location, description, technicianId });
    bot.sendMessage(response.chat.id, `Job assigned with ID: ${jobId}`);
  });
});

async function getAllTechniciansData( chatId) {  
   try {
  const technicians = await getAllTechnicians();
  // console.log(technicians);
  if (technicians.length > 0) {
    const inlineKeyboard = technicians.map(technician => {
      const statusMessage = `Status: ${technician.status === "1" ? "🟢" : "🔴"}`;

      return [{ 
        text: statusMessage + " " + technician.firstName + " " + technician.lastName, 
        callback_data: `technician_${technician.id}` 
      }];
    });

    // Add the "Close" button at the end of the inline keyboard
    inlineKeyboard.push([{ text: 'Close', callback_data: 'close' }]);

    bot.sendMessage(chatId, 'Select a technician to view details:', {
      reply_markup: {
        inline_keyboard: inlineKeyboard,
      },
    });
  } else {
    bot.sendMessage(chatId, 'No technicians found.');
  }
} catch (error) {
  console.error('Error fetching technicians:', error);
  bot.sendMessage(chatId, 'An error occurred while fetching technicians.');
}}

 
bot.onText(/View Technicians/, async (msg) => {
  const chatId = msg.chat.id
  if(chatId === adminId){
  await getAllTechniciansData(chatId)
  }
  
  });
  bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if(data === 'back'){
      bot.deleteMessage(chatId, messageId).then(()=>{
          getAllTechniciansData(chatId)

      })
    }

    if (data.startsWith('technician_')) {
      const technicianId = data.split('_')[1];
  
      try {
        const technician = await getTechnicianById(technicianId);
        if (technician) {
          
          displayTechnicianDetailsWithEditOptions(chatId, technician);
          bot.deleteMessage(chatId,messageId)
        } else {
          bot.sendMessage(chatId, `Technician with ID ${technicianId} not found.`);
        }
      } catch (error) {
        console.error('Error fetching technician details:', error);
        bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
      }
    }
  
    // Handle edits
    else if (data.startsWith('update_')) {
      const [action, technicianId] = data.split('_').slice(1);
      const fieldMap = {
        firstName: "firstName",
        lastName:"lastName",
        phone: "Phone",
        email: "Email",
        skills: "Skills",
        experience: "Experience",
       

      };
      bot.deleteMessage(chatId, messageId).then(()=>{
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[action]}:`, createCancelKeyboard());

      })

      
      bot.once('message', async (msg) => {
        const updatedValue = msg.text;
  
        // Here, you would update the technician's information in your database
        await updateTechnicianAttribute(technicianId, action, updatedValue);
        
        bot.sendMessage(chatId, `${fieldMap[action]} updated successfully!`);
  
        // Optionally, redisplay the technician details after the update
         try {
            const technician = await getTechnicianById(technicianId);
            if (technician) {
              displayTechnicianDetailsWithEditOptions(chatId, technician);
              // bot.deleteMessage(chatId,messageId)
            } else {
              bot.sendMessage(chatId, `Technician with ID ${technicianId} not found.`);
            }
          } catch (error) {
            console.error('Error fetching technician details:', error);
            bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
          }
      });
    }
   
 
  });

  bot.on('callback_query', async (query) => {
    const callbackData = query.data; // Get the callback data
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    // Split the callback data
    const [action, technicianId, status] = callbackData.split('_');

    if (action === 'ChangeStatus') {
      bot.deleteMessage(chatId, messageId);
        // Function to create inline keyboard
        const createInlineKeyboard = (status) => {
            return {
                inline_keyboard: [
                    [
                        {
                            text: status === "1" ? '🟢 Make It Inactive' : '🔴 Make It Active',
                            callback_data: `buttonActive_${technicianId}_${status === "1" ? 0 : 1}`,
                        }
                    ]
                ]
            };
        };

        // Send a message asking to select status with inline keyboard
        await bot.sendMessage(chatId, `Please select status:`, {
            reply_markup: createInlineKeyboard(status),
        });

    } else if (action === 'buttonActive') {
        

        // Update the technician's status in the database
        await updateTechnicianStatus(technicianId, status);
// Optionally, redisplay the technician details after the update
try {
    const technician = await getTechnicianById(technicianId);
    if (technician) {
      displayTechnicianDetailsWithEditOptions(chatId, technician);
      
      bot.deleteMessage(chatId,messageId)
    } else {
      bot.sendMessage(chatId, `Technician with ID ${technicianId} not found.`);
    }
  } catch (error) {
    console.error('Error fetching technician details:', error);
    bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
  }
        // Notify the user
        await bot.sendMessage(chatId, `Status for technician has been changed to ${status}.`);
    }
});

 
  
  async function displayTechnicianDetailsWithEditOptions(chatId, technician) {
    const technicianId = technician.id;
     const status = technician.status
     const statusMessage = `Status: ${status === "1" ? '🟢 Active' : '🔴 InActive'}`

    const message = `Updated Technician Details:\nFull Name: ${technician.firstName} ${technician.lastName}\nPhone: ${technician.phone}\nEmail: ${technician.email}\nSkills: ${technician.skills}\nExperience: ${technician.experience} years\n${statusMessage}`;
    
    const options = {
      reply_markup: {
        inline_keyboard: [
            [{ text: 'Edit First Name', callback_data: `update_firstName_${technicianId}` },{ text: 'Edit Last Name', callback_data: `update_lastName_${technicianId}` }],
             
            [{ text: 'Edit Email', callback_data: `update_email_${technicianId}` },{ text: 'Edit Skills', callback_data: `update_skills_${technicianId}` }],
     
            [{ text: 'Edit Experience', callback_data: `update_experience_${technicianId}` },{ text: 'Edit Phone', callback_data: `update_phone_${technicianId}` }],
            [{ text: 'Edit Status', callback_data: `ChangeStatus_${technicianId}_${status}` },{ text: 'Back', callback_data: 'back' }],

        ],
      },
    };
    
    return bot.sendMessage(chatId, message, options)
    .then(sentMessage => sentMessage.message_id);  // Return the messageId
      }
  
// // View Technician Command
// bot.onText(/\/viewtechnician /, async (msg, match) => {
//   const technicianId = match[1];
//   const technician = await getTechnicianById(technicianId);
//   if (technician) {
//     bot.sendMessage(msg.chat.id, `Technician Details:\nName: ${technician.name}\nPhone: ${technician.phone}\nEmail: ${technician.email}\nSkills: ${technician.skills}\nExperience: ${technician.experience} years`);
//   } else {
//     bot.sendMessage(msg.chat.id, `Technician with ID ${technicianId} not found.`);
//   }
// });
// // View All Technicians Command
// bot.onText(/\/viewtechnicians/, async (msg) => {
//     const technicians = await getAllTechnicians();
//     if (technicians.length > 0) {
//       let message = 'Technician Details:\n\n';
//       technicians.forEach((technician, index) => {
//         message += `👷‍♂️ Technician ${index + 1}:\nName: ${technician.name}\nPhone: ${technician.phone}\nEmail: ${technician.email}\nSkills: ${technician.skills}\nExperience: ${technician.experience} years\n\n`;
//       });
//       bot.sendMessage(msg.chat.id, message);
//     } else {
//       bot.sendMessage(msg.chat.id, 'No technicians found.');
//     }
//   });
  
// View Job Command
bot.onText(/\/viewjob (.+)/, async (msg, match) => {
  const jobId = match[1];
  const job = await getJobById(jobId);
  if (job) {
    bot.sendMessage(msg.chat.id, `Job Details:\nService Type: ${job.service_type}\nLocation: ${job.location}\nDescription: ${job.description}\nTechnician ID: ${job.technician_id}\nStatus: ${job.status}`);
  } else {
    bot.sendMessage(msg.chat.id, `Job with ID ${jobId} not found.`);
  }
});

// Additional commands for updating technician/job info, viewing job statuses, etc.



//add admin 
let adminRegistration = {}; // Temporary storage for technician details

bot.onText(/\/adminRegisteration/, async(msg) => {
    const chatId = msg.chat.id;
    const user = msg.from;
    const isAlreadyRegistered = await handleAdminRegistration(chatId);

    if (!isAlreadyRegistered) {
    adminRegistration[chatId] = {
        step: 'admin_contact',
        firstName: user.first_name || '',
        lastName: user.last_name || '',
        username: user.username || '',
        chatId: chatId,
        status: "0",
    };

    bot.sendMessage(chatId, "Please share the technician's phone number by clicking the button below:", {
        reply_markup: {
            keyboard: [
                [{
                    text: "Share Contact",
                    request_contact: true
                }]
            ],
            one_time_keyboard: true,
            resize_keyboard:true
        }
    });
  } 
});
function escapeMarkdown(text) {
  return text.replace(/([*_`[\]])/g, '\\$1');
}

bot.on('contact', (msg) => {
    const chatId = msg.chat.id;
    const contact = msg.contact;
    console.log(adminRegistration[chatId])
    if (adminRegistration[chatId] && adminRegistration[chatId].step === 'admin_contact') {
        adminRegistration[chatId].phone = contact.phone_number;
        adminRegistration[chatId].step = 'admin_email';

        bot.sendMessage(chatId, 'Please enter the technician\'s email address:', createCancelKeyboard());
    }
});

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (!adminRegistration[chatId] || adminRegistration[chatId].isAdminEditing || msg.contact) return;

    const registration = adminRegistration[chatId];

    switch (registration.step) {
        case 'admin_email':
            registration.email = text;
            registration.role = "User";
            registration.step = 'admin_preview';
            displayAdminRegistrationDetails(chatId);
            break;

        default:
            bot.sendMessage(chatId, 'Registration step not recognized. Please start over.', createCancelKeyboard());
            break;
    }
});
async function displayAdminRegistrationDetails(chatId) {
  const registration = adminRegistration[chatId];

  const previewMessage = `
  👷‍♂️ *Technician Preview* 👷‍♂️
  First Name: ${escapeMarkdown(registration.firstName)}
  Last Name: ${escapeMarkdown(registration.lastName)}
  Username: ${escapeMarkdown(registration.username)}
  Phone: ${escapeMarkdown(registration.phone)}
  Email: ${escapeMarkdown(registration.email)}
   
  `;

  const options = {
      parse_mode: 'Markdown',
      reply_markup: {
          inline_keyboard: [
              [{ text: 'Edit First Name', callback_data: 'AdminEdit_firstName' }, { text: 'Edit Last Name', callback_data: 'AdminEdit_lastName' }],
              [{ text: 'Edit Email', callback_data: 'AdminEdit_email' } ],
              [{ text: 'Edit Phone', callback_data: 'AdminEdit_phone' }],
              [{ text: 'Confirm', callback_data: 'adminConfirm' }, { text: 'Close', callback_data: 'close' }],
          ],
      },
  };

  if (!registration.previewMessageId) {
      const sentMessage = await bot.sendMessage(chatId, previewMessage, options);
      registration.previewMessageId = sentMessage.message_id;
  } else {
      await bot.editMessageText(previewMessage, {
          chat_id: chatId,
          message_id: registration.previewMessageId,
          parse_mode: 'Markdown',
          reply_markup: options.reply_markup
      });
  }
}

bot.on('callback_query', (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;
  const messageId = callbackQuery.message.message_id;

  if (data.startsWith('AdminEdit_')) {
      const field = data.split('_')[1];
      const fieldMap = {
          firstName: "First Name",
          lastName: "Last Name",
          phone: "Phone",
          email: "Email",
          role: "Role",
      };

      adminRegistration[chatId].isAdminEditing = true;
      bot.sendMessage(chatId, `Please enter a new ${fieldMap[field]}:`);

      bot.once('message', (msg) => {
          if (!adminRegistration[chatId] || !adminRegistration[chatId].isAdminEditing) return;

          const text = msg.text;
          adminRegistration[chatId][field] = text;
          adminRegistration[chatId].isAdminEditing = false;

          // Re-display the updated preview
          displayAdminRegistrationDetails(chatId);

          // Send success message replying to the message that displayed the updated preview
          bot.sendMessage(chatId, `${fieldMap[field]} updated successfully!`, {
              reply_to_message_id: adminRegistration[chatId].previewMessageId
          });
      });

  } else if (data === 'adminConfirm') {
      createAdmin(adminRegistration[chatId]).then((technicianId) => {
          bot.sendMessage(chatId, `Technician added with ID: ${technicianId}`, {
              reply_markup: {
                  remove_keyboard: true
              }
          }).then(() => {
              bot.deleteMessage(chatId, messageId);
          });
          delete adminRegistration[chatId]; // Clear registration data
      });
  } else if (data === 'close') {
      bot.deleteMessage(chatId, messageId).then(() => {
          delete adminRegistration[chatId];
      });
  }
});

//view admins

async function getAllAdminsData( chatId) {  
  try {
 const admins = await getAllAdmins();
 // console.log(admins);
 if (admins.length > 0) {
   const inlineKeyboard = admins.map(admin => {
     const statusMessage = `Status: ${admin.status === "1" ? "🟢" : "🔴"}`;

     return [{ 
       text: statusMessage + " " + admin.firstName + " " + admin.lastName, 
       callback_data: `viewAdmin_${admin.id}` 
     }];
   });

   // Add the "Close" button at the end of the inline keyboard
   inlineKeyboard.push([{ text: 'Close', callback_data: 'close' }]);

   bot.sendMessage(chatId, 'Select a admin to view details:', {
     reply_markup: {
       inline_keyboard: inlineKeyboard,
     },
   });
 } else {
   bot.sendMessage(chatId, 'No admins found.');
 }
} catch (error) {
 console.error('Error fetching admins:', error);
 bot.sendMessage(chatId, 'An error occurred while fetching admins.');
}}

bot.onText(/View Admins/, async (msg) => {
  const chatId = msg.chat.id
  if(chatId === adminId){

  await getAllAdminsData(chatId)
  }
  
  });
  bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if(data === 'adminBack'){
      bot.deleteMessage(chatId, messageId).then(()=>{
        getAllAdminsData(chatId)

      })
    }

    if (data.startsWith('viewAdmin_')) {
      const adminId = data.split('_')[1];
  
      try {
        const technician = await getAdminById(adminId);
        if (technician) {
          
          displayAdminDetailsWithEditOptions(chatId, technician);
          bot.deleteMessage(chatId,messageId)
        } else {
          bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
        }
      } catch (error) {
        console.error('Error fetching technician details:', error);
        bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
      }
    }
  
    // Handle edits
    else if (data.startsWith('adminUpdate_')) {
      const [action, adminId] = data.split('_').slice(1);
      const fieldMap = {
        firstName: "firstName",
        lastName:"lastName",
        phone: "Phone",
        email: "Email",
        role: "Role",
        

      };
      bot.deleteMessage(chatId, messageId).then(()=>{
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[action]}:`, createCancelKeyboard());

      })

      
      bot.once('message', async (msg) => {
        const updatedValue = msg.text;
  
        // Here, you would update the technician's information in your database
        await updateAdminAttribute(adminId, action, updatedValue);
        
        bot.sendMessage(chatId, `${fieldMap[action]} updated successfully!`);
  
        // Optionally, redisplay the technician details after the update
         try {
            const technician = await getAdminById(adminId);
            if (technician) {
              displayAdminDetailsWithEditOptions(chatId, technician);
              bot.deleteMessage(chatId,messageId)
            } else {
              bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
            }
          } catch (error) {
            console.error('Error fetching technician details:', error);
            bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
          }
      });
    }
   
 
  });

  bot.on('callback_query', async (query) => {
    const callbackData = query.data; // Get the callback data
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    // Split the callback data
    const [action, adminId, status] = callbackData.split('_');

    if (action === 'ChangeAdminStatus') {
      bot.deleteMessage(chatId, messageId);
        // Function to create inline keyboard
        const createInlineKeyboard = (status) => {
            return {
                inline_keyboard: [
                    [
                        {
                            text: status === "1" ? '🟢 Make It Inactive' : '🔴 Make It Active',
                            callback_data: `buttonAdminActive_${adminId}_${status === "1" ? 0 : 1}`,
                        }
                    ]
                ]
            };
        };

        // Send a message asking to select status with inline keyboard
        await bot.sendMessage(chatId, `Please select status:`, {
            reply_markup: createInlineKeyboard(status),
        });

    } else if (action === 'buttonAdminActive') {
        

        // Update the technician's status in the database
        await updateAdminStatus(adminId, status);
// Optionally, redisplay the technician details after the update
try {
    const technician = await getAdminById(adminId);
    if (technician) {
      displayAdminDetailsWithEditOptions(chatId, technician);
      
      // bot.deleteMessage(chatId,messageId)
    } else {
      bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
    }
  } catch (error) {
    console.error('Error fetching technician details:', error);
    bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
  }
        // Notify the user
        await bot.sendMessage(chatId, `Status for technician has been changed to ${status}.`);
    }
});


async function displayAdminDetailsWithEditOptions(chatId, technician) {
  const technicianId = technician.id;
   const status = technician.status
   const statusMessage = `  ${status === "1" ? '🟢 Active' : '🔴 InActive'}`

  const message = `Updated Admin Details:\nFull Name: ${technician.firstName} ${technician.lastName}\nPhone: ${technician.phone}\nEmail: ${technician.email}\nRole: ${technician.role} \n${statusMessage}`;
  
  const options = {
    reply_markup: {
      inline_keyboard: [
          [{ text: 'Edit First Name', callback_data: `adminUpdate_firstName_${technicianId}` },{ text: 'Edit Last Name', callback_data: `adminUpdate_lastName_${technicianId}` }],
           
          [{ text: 'Edit Email', callback_data: `adminUpdate_email_${technicianId}` },{ text: 'Edit Role', callback_data: `adminUpdate_role_${technicianId}` }],
   
          [ { text: 'Edit Phone', callback_data: `adminUpdate_phone_${technicianId}` }],
          [{ text: 'Edit Status', callback_data: `ChangeAdminStatus_${technicianId}_${status}` },{ text: 'Back', callback_data: 'adminBack' }],

      ],
    },
  };
  
  return bot.sendMessage(chatId, message, options)
  .then(sentMessage => sentMessage.message_id);  // Return the messageId
    }

    //machine add 

    let machineRegistration = {}; // Temporary storage for technician details

    bot.onText(/Add Machine/, (msg) => {
        const chatId = msg.chat.id;
    
        machineRegistration[chatId] = {
            step: 'machine_name'
        };
        bot.sendMessage(chatId, "Please enter the machine's name:");
    });
    
    bot.on('message', async (msg) => {
        const chatId = msg.chat.id;
        const text = msg.text;
      
        if (!machineRegistration[chatId] || machineRegistration[chatId].isEditingMachine) return;
      
        const registration = machineRegistration[chatId];
      
        switch (registration.step) {
            case 'machine_name':
                registration.machineName = text;
                registration.step = 'machine_shortCode';
                bot.sendMessage(chatId, 'Please enter machine short code:', createCancelKeyboard());
                break;
            case 'machine_shortCode':
                registration.machineShortCode = text;           
                registration.status = 1;
                registration.chatId = chatId;
                registration.step = 'preview';
                displayMachineRegistrationDetails(chatId);
                break;
            default:
                bot.sendMessage(chatId, 'Registration step not recognized. Please start over.', createCancelKeyboard());
                break;
        }
    });
      
    async function displayMachineRegistrationDetails(chatId) {
        const registration = machineRegistration[chatId];
        const previewMessage = `
        👷‍♂️ *Machine Preview* 👷‍♂️
        Machine Name: ${registration.machineName}
        Machine Code: ${registration.machineShortCode}
        `;
      
        const options = {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Edit Machine Name', callback_data: 'editMachine_machineName' },{ text: 'Edit Machine Code', callback_data: 'editMachine_machineShortCode' }],
                    [{ text: 'Confirm', callback_data: 'confirmMachine' },{ text: 'Close', callback_data: 'MachineClose' }],
                ],
            },
        };
      
        if (!registration.previewMessageId) {
            const sentMessage = await bot.sendMessage(chatId, previewMessage, options);
            registration.previewMessageId = sentMessage.message_id;
        } else {
            await bot.editMessageText(previewMessage, {
                chat_id: chatId,
                message_id: registration.previewMessageId,
                parse_mode: 'Markdown',
                reply_markup: options.reply_markup
            });
        }
    }
      
    bot.on('callback_query', (callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;
        const messageId = callbackQuery.message.message_id;
      const action = data.split('_')[0];
        if (action === 'editMachine') {
            const field = data.split('_')[1];
            const fieldMap = {
                machineName: "machineName",
                machineShortCode: "machineShortCode",
            };
          
            machineRegistration[chatId].isEditingMachine = true;
    
            if (fieldMap[field]) {
                bot.sendMessage(chatId, `Please enter a new ${fieldMap[field]}:`);
    
                bot.once('message', (msg) => {
                    const text = msg.text;
                    machineRegistration[chatId][fieldMap[field]] = text;
                    machineRegistration[chatId].isEditingMachine = false;
                    
                    displayMachineRegistrationDetails(chatId); // Re-display the preview after editing
               

          // Send success message replying to the message that displayed the updated preview
          bot.sendMessage(chatId, `${fieldMap[field]} updated successfully!`, {
              reply_to_message_id: machineRegistration[chatId].previewMessageId
          });
                });
            } else {
                bot.sendMessage(chatId, 'Invalid field selected for editing.');
            }
    
        } else if (data === 'confirmMachine') {
            createMachine(machineRegistration[chatId]).then((machineId) => {
                const messageId = machineRegistration[chatId].previewMessageId;
    
                bot.sendMessage(chatId, `Machine added with ID: ${machineId}`).then(() => {
                    bot.deleteMessage(chatId, messageId);
                });
                delete machineRegistration[chatId]; // Clear registration data
            });
        } else if (data === 'MachineClose') {
            bot.deleteMessage(chatId, messageId).then(() => {
                delete machineRegistration[chatId];
            });
        }
    });
    
//view machines

 
async function getAllMachinesData( chatId) {  
  try {
 const machines = await getAllMachines();
 // console.log(machines);
 if (machines.length > 0) {
   const inlineKeyboard = machines.map(machine => {
     const statusMessage = `Status: ${machine.status === "1" ? "🟢" : "🔴"}`;

     return [{ 
       text: statusMessage + " " + machine.machineName + "    " + machine.machineShortCode, 
       callback_data: `viewMachine_${machine.id}` 
     }];
   });

   // Add the "Close" button at the end of the inline keyboard
   inlineKeyboard.push([{ text: 'Close', callback_data: 'close' }]);

   bot.sendMessage(chatId, 'Select a machine to view details:', {
     reply_markup: {
       inline_keyboard: inlineKeyboard,
     },
   });
 } else {
   bot.sendMessage(chatId, 'No machines found.');
 }
} catch (error) {
 console.error('Error fetching admins:', error);
 bot.sendMessage(chatId, 'An error occurred while fetching admins.');
}}

bot.onText(/View Machines/, async (msg) => {
  const chatId = msg.chat.id
  if(chatId === adminId){

  await getAllMachinesData(chatId)
  }
  
  });
  bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if(data === 'machineBack'){
      bot.deleteMessage(chatId, messageId).then(()=>{
        getAllMachinesData(chatId)

      })
    }

    if (data.startsWith('viewMachine_')) {
      const machineId = data.split('_')[1];
  
      try {
        const machine = await getMachineById(machineId);
        if (machine) {
          
          displayMachineDetailsWithEditOptions(chatId, machine);
          bot.deleteMessage(chatId,messageId)
        } else {
          bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
        }
      } catch (error) {
        console.error('Error fetching machine details:', error);
        bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
      }
    }
  
    // Handle edits
    else if (data.startsWith('MachineUpdate_')) {
      const [action, adminId] = data.split('_').slice(1);
      const fieldMap = {
        machineName: "machineName",
        machineShortCode:"machineShortCode",
       
        

      };
      bot.deleteMessage(chatId, messageId).then(()=>{
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[action]}:`, createCancelKeyboard());

      })

      
      bot.once('message', async (msg) => {
        const updatedValue = msg.text;
  
        // Here, you would update the technician's information in your database
        await updateMachineAttribute(adminId, action, updatedValue);
        
        bot.sendMessage(chatId, `${fieldMap[action]} updated successfully!`);
  
        // Optionally, redisplay the technician details after the update
         try {
            const technician = await getMachineById(adminId);
            if (technician) {
              displayMachineDetailsWithEditOptions(chatId, technician);
              // bot.deleteMessage(chatId,messageId)
            } else {
              bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
            }
          } catch (error) {
            console.error('Error fetching technician details:', error);
            bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
          }
      });
    }
   
 
  });

  bot.on('callback_query', async (query) => {
    const callbackData = query.data; // Get the callback data
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    // Split the callback data
    const [action, machineId, status] = callbackData.split('_');

    if (action === 'ChangeMachineStatus') {
      bot.deleteMessage(chatId, messageId);
        // Function to create inline keyboard
        const createInlineKeyboard = (status) => {
            return {
                inline_keyboard: [
                    [
                        {
                            text: status === "1" ? '🟢 Make It Inactive' : '🔴 Make It Active',
                            callback_data: `buttonMachineActive_${machineId}_${status === "1" ? 0 : 1}`,
                        }
                    ]
                ]
            };
        };

        // Send a message asking to select status with inline keyboard
        await bot.sendMessage(chatId, `Please select status:`, {
            reply_markup: createInlineKeyboard(status),
        });

    } 
    else if (action === 'buttonMachineActive') {
        

        // Update the technician's status in the database
        await updateMachineStatus(machineId, status);
// Optionally, redisplay the technician details after the update
try {
    const machine = await getMachineById(machineId);
    if (machine) {
      displayMachineDetailsWithEditOptions(chatId, machine);
      
      bot.deleteMessage(chatId,messageId)
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
  } catch (error) {
    console.error('Error fetching machine details:', error);
    bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
  }
        // Notify the user
        await bot.sendMessage(chatId, `Status for machine has been changed to ${status}.`);
    }
    else if(action === 'deleteMachine'){
      const machine = await deleteMachineById(machineId);
    if (machine) {
      bot.deleteMessage(chatId, messageId).then(()=>{
  
      bot.sendMessage(chatId, `Machine with ID ${machineId} has been deleted.`);
      getAllMachinesData(chatId)
            
    })
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
    }
});


async function displayMachineDetailsWithEditOptions(chatId, machine) {
  const machineId = machine.id;
   const status = machine.status
   const statusMessage = `Status: ${status === "1" ? '🟢 Active' : '🔴 InActive'}`

  const message = `Updated Machine Details:\n Machine  Name: ${machine.machineName} \n Machine  Code:${machine.machineShortCode} \n${statusMessage}`;
  
  const options = {
    reply_markup: {
      inline_keyboard: [
          [{ text: 'Edit Machine Name', callback_data: `MachineUpdate_machineName_${machineId}` },{ text: 'Edit Machine Code', callback_data: `MachineUpdate_machineShortCode_${machineId}` }],
 
          [{ text: 'Edit Status', callback_data: `ChangeMachineStatus_${machineId}_${status}` },{ text: 'Delete Mchine', callback_data: `deleteMachine_${machineId}` }],
          [{ text: 'Back', callback_data: 'machineBack' }],

      ],
    },
  };
  
  return bot.sendMessage(chatId, message, options)
  .then(sentMessage => sentMessage.message_id);  // Return the messageId
    }


    //company add 

    let companyRegistration = {}; // Temporary storage for technician details

    bot.onText(/Add Company/, (msg) => {
        const chatId = msg.chat.id;
    
        companyRegistration[chatId] = {
            step: 'company_name'
        };
        bot.sendMessage(chatId, "Please enter the company's name:");
    });
    
    bot.on('message', async (msg) => {
        const chatId = msg.chat.id;
        const text = msg.text;
      
        if (!companyRegistration[chatId] || companyRegistration[chatId].isEditingCompany) return;
      
        const registration = companyRegistration[chatId];
      
        switch (registration.step) {
            case 'company_name':
                registration.CompanyName = text;
                registration.step = 'company_shortCode';
                bot.sendMessage(chatId, 'Please enter Company short code:', createCancelKeyboard());
                break;
            case 'company_shortCode':
                registration.CompanyShortCode = text;           
                registration.status = 1;
                registration.chatId = chatId;
                registration.step = 'preview';
                displaycompanyRegistrationDetails(chatId);
                break;
            default:
                bot.sendMessage(chatId, 'Registration step not recognized. Please start over.', createCancelKeyboard());
                break;
        }
    });
      
    async function displaycompanyRegistrationDetails(chatId) {
        const registration = companyRegistration[chatId];
        const previewMessage = `
        👷‍♂️ *Company Preview* 👷‍♂️
        Company Name: ${registration.CompanyName}
        Company Code: ${registration.CompanyShortCode}
        `;
      
        const options = {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Edit Company Name', callback_data: 'editCompany_CompanyName' },{ text: 'Edit Company Code', callback_data: 'editCompany_CompanyShortCode' }],
                    [{ text: 'Confirm', callback_data: 'confirmCompany' },{ text: 'Close', callback_data: 'CompanyClose' }],
                ],
            },
        };
      
        if (!registration.previewMessageId) {
            const sentMessage = await bot.sendMessage(chatId, previewMessage, options);
            registration.previewMessageId = sentMessage.message_id;
        } else {
            await bot.editMessageText(previewMessage, {
                chat_id: chatId,
                message_id: registration.previewMessageId,
                parse_mode: 'Markdown',
                reply_markup: options.reply_markup
            });
        }
    }
      
    bot.on('callback_query', (callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;
        const messageId = callbackQuery.message.message_id;
      const action = data.split('_')[0];
        if (action === 'editCompany') {
            const field = data.split('_')[1];
            const fieldMap = {
                CompanyName: "CompanyName",
                CompanyShortCode: "CompanyShortCode",
            };
          
            companyRegistration[chatId].isEditingCompany = true;
    
            if (fieldMap[field]) {
                bot.sendMessage(chatId, `Please enter a new ${fieldMap[field]}:`);
    
                bot.once('message', (msg) => {
                    const text = msg.text;
                    companyRegistration[chatId][fieldMap[field]] = text;
                    companyRegistration[chatId].isEditingCompany = false;
                    
                    displaycompanyRegistrationDetails(chatId); // Re-display the preview after editing
               

          // Send success message replying to the message that displayed the updated preview
          bot.sendMessage(chatId, `${fieldMap[field]} updated successfully!`, {
              reply_to_message_id: companyRegistration[chatId].previewMessageId
          });
                });
            } else {
                bot.sendMessage(chatId, 'Invalid field selected for editing.');
            }
    
        } else if (data === 'confirmCompany') {
            createCompany(companyRegistration[chatId]).then((machineId) => {
                const messageId = companyRegistration[chatId].previewMessageId;
    
                bot.sendMessage(chatId, `Company added with ID: ${machineId}`).then(() => {
                    bot.deleteMessage(chatId, messageId);
                });
                delete companyRegistration[chatId]; // Clear registration data
            });
        } else if (data === 'CompanyClose') {
            bot.deleteMessage(chatId, messageId).then(() => {
                delete companyRegistration[chatId];
            });
        }
    });
    
//view machines

 
async function getAllCompanysData( chatId) {  
  try {
 const machines = await getAllCompanys();
 // console.log(machines);
 if (machines.length > 0) {
   const inlineKeyboard = machines.map(machine => {
     const statusMessage = `Status: ${machine.status === "1" ? "🟢" : "🔴"}`;

     return [{ 
       text: statusMessage + " " + machine.CompanyName + "    " + machine.CompanyShortCode, 
       callback_data: `viewCompany_${machine.id}` 
     }];
   });

   // Add the "Close" button at the end of the inline keyboard
   inlineKeyboard.push([{ text: 'Close', callback_data: 'close' }]);

   bot.sendMessage(chatId, 'Select a machine to view details:', {
     reply_markup: {
       inline_keyboard: inlineKeyboard,
     },
   });
 } else {
   bot.sendMessage(chatId, 'No machines found.');
 }
} catch (error) {
 console.error('Error fetching admins:', error);
 bot.sendMessage(chatId, 'An error occurred while fetching admins.');
}}

bot.onText(/View Companies/, async (msg) => {
  const chatId = msg.chat.id
  if(chatId === adminId){

  await getAllCompanysData(chatId)
  }
  
  });
  bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if(data === 'CompanyBack'){
      bot.deleteMessage(chatId, messageId).then(()=>{
        getAllCompanysData(chatId)

      })
    }

    if (data.startsWith('viewCompany_')) {
      const machineId = data.split('_')[1];
  
      try {
        const machine = await getCompanyById(machineId);
        if (machine) {
          
          displayCompanyDetailsWithEditOptions(chatId, machine);
          bot.deleteMessage(chatId,messageId)
        } else {
          bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
        }
      } catch (error) {
        console.error('Error fetching machine details:', error);
        bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
      }
    }
  
    // Handle edits
    else if (data.startsWith('CompanyUpdate_')) {
      const [action, adminId] = data.split('_').slice(1);
      const fieldMap = {
        CompanyName: "CompanyName",
        CompanyShortCode:"CompanyShortCode",
       
        

      };
      bot.deleteMessage(chatId, messageId).then(()=>{
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[action]}:`, createCancelKeyboard());

      })

      
      bot.once('message', async (msg) => {
        const updatedValue = msg.text;
  
        // Here, you would update the technician's information in your database
        await updateCompanyAttribute(adminId, action, updatedValue);
        
        bot.sendMessage(chatId, `${fieldMap[action]} updated successfully!`);
  
        // Optionally, redisplay the technician details after the update
         try {
            const technician = await getCompanyById(adminId);
            if (technician) {
              displayCompanyDetailsWithEditOptions(chatId, technician);
              // bot.deleteMessage(chatId,messageId)
            } else {
              bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
            }
          } catch (error) {
            console.error('Error fetching technician details:', error);
            bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
          }
      });
    }
   
 
  });

  bot.on('callback_query', async (query) => {
    const callbackData = query.data; // Get the callback data
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    // Split the callback data
    const [action, machineId, status] = callbackData.split('_');

    if (action === 'ChangeCompanyStatus') {
      bot.deleteMessage(chatId, messageId);
        // Function to create inline keyboard
        const createInlineKeyboard = (status) => {
            return {
                inline_keyboard: [
                    [
                        {
                            text: status === "1" ? '🟢 Make It Inactive' : '🔴 Make It Active',
                            callback_data: `buttonCompanyActive_${machineId}_${status === "1" ? 0 : 1}`,
                        }
                    ]
                ]
            };
        };

        // Send a message asking to select status with inline keyboard
        await bot.sendMessage(chatId, `Please select status:`, {
            reply_markup: createInlineKeyboard(status),
        });

    } 
    else if (action === 'buttonCompanyActive') {
        

        // Update the technician's status in the database
        await updateCompanyStatus(machineId, status);
// Optionally, redisplay the technician details after the update
try {
    const machine = await getCompanyById(machineId);
    if (machine) {
      displayCompanyDetailsWithEditOptions(chatId, machine);
      
      bot.deleteMessage(chatId,messageId)
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
  } catch (error) {
    console.error('Error fetching machine details:', error);
    bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
  }
        // Notify the user
        await bot.sendMessage(chatId, `Status for machine has been changed to ${status}.`);
    }
    else if(action === 'deleteCompany'){
      const machine = await deleteCompanyById(machineId);
    if (machine) {
      bot.deleteMessage(chatId, messageId).then(()=>{
  
      bot.sendMessage(chatId, `Machine with ID ${machineId} has been deleted.`);
      getAllCompanysData(chatId)
            
    })
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
    }
});


async function displayCompanyDetailsWithEditOptions(chatId, machine) {
  const machineId = machine.id;
   const status = machine.status
   const statusMessage = `Status: ${status === "1" ? '🟢 Active' : '🔴 InActive'}`

  const message = `Updated Company Details:\n Company  Name: ${machine.CompanyName} \n Company  Code:${machine.CompanyShortCode} \n${statusMessage}`;
  
  const options = {
    reply_markup: {
      inline_keyboard: [
          [{ text: 'Edit Company Name', callback_data: `CompanyUpdate_CompanyName_${machineId}` },{ text: 'Edit Company Code', callback_data: `CompanyUpdate_CompanyShortCode_${machineId}` }],
 
          [{ text: 'Edit Status', callback_data: `ChangeCompanyStatus_${machineId}_${status}` },{ text: 'Delete Company', callback_data: `deleteCompany_${machineId}` }],
          [{ text: 'Back', callback_data: 'CompanyBack' }],

      ],
    },
  };
  
  return bot.sendMessage(chatId, message, options)
  .then(sentMessage => sentMessage.message_id);  // Return the messageId
    }

    //locations add 

    let locationRegistration = {}; // Temporary storage for technician details

    bot.onText(/Add Location/, (msg) => {
        const chatId = msg.chat.id;
    
        locationRegistration[chatId] = {
            step: 'Location_name'
        };
        bot.sendMessage(chatId, "Please enter the Location's name:");
    });
    
    bot.on('message', async (msg) => {
        const chatId = msg.chat.id;
        const text = msg.text;
      
        if (!locationRegistration[chatId] || locationRegistration[chatId].isEditingLocation) return;
      
        const registration = locationRegistration[chatId];
      
        switch (registration.step) {
            case 'Location_name':
                registration.LocationName = text;
                registration.step = 'Location_shortCode';
                bot.sendMessage(chatId, 'Please enter Location short code:', createCancelKeyboard());
                break;
            case 'Location_shortCode':
                registration.LocationShortCode = text;           
                registration.status = 1;
                registration.chatId = chatId;
                registration.step = 'preview';
                displaylocationRegistrationDetails(chatId);
                break;
            default:
                bot.sendMessage(chatId, 'Registration step not recognized. Please start over.', createCancelKeyboard());
                break;
        }
    });
      
    async function displaylocationRegistrationDetails(chatId) {
        const registration = locationRegistration[chatId];
        const previewMessage = `
        👷‍♂️ *Location Preview* 👷‍♂️
        Location Name: ${registration.LocationName}
        Location Code: ${registration.LocationShortCode}
        `;
      
        const options = {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Edit Location Name', callback_data: 'editLocation_LocationName' },{ text: 'Edit Location Code', callback_data: 'editLocation_LocationShortCode' }],
                    [{ text: 'Confirm', callback_data: 'confirmLocation' },{ text: 'Close', callback_data: 'LocationClose' }],
                ],
            },
        };
      
        if (!registration.previewMessageId) {
            const sentMessage = await bot.sendMessage(chatId, previewMessage, options);
            registration.previewMessageId = sentMessage.message_id;
        } else {
            await bot.editMessageText(previewMessage, {
                chat_id: chatId,
                message_id: registration.previewMessageId,
                parse_mode: 'Markdown',
                reply_markup: options.reply_markup
            });
        }
    }
      
    bot.on('callback_query', (callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;
        const messageId = callbackQuery.message.message_id;
      const action = data.split('_')[0];
        if (action === 'editLocation') {
            const field = data.split('_')[1];
            const fieldMap = {
                LocationName: "LocationName",
                LocationShortCode: "LocationShortCode",
            };
          
            locationRegistration[chatId].isEditingLocation = true;
    
            if (fieldMap[field]) {
                bot.sendMessage(chatId, `Please enter a new ${fieldMap[field]}:`);
    
                bot.once('message', (msg) => {
                    const text = msg.text;
                    locationRegistration[chatId][fieldMap[field]] = text;
                    locationRegistration[chatId].isEditingLocation = false;
                    
                    displaylocationRegistrationDetails(chatId); // Re-display the preview after editing
               

          // Send success message replying to the message that displayed the updated preview
          bot.sendMessage(chatId, `${fieldMap[field]} updated successfully!`, {
              reply_to_message_id: locationRegistration[chatId].previewMessageId
          });
                });
            } else {
                bot.sendMessage(chatId, 'Invalid field selected for editing.');
            }
    
        } else if (data === 'confirmLocation') {
            createLocation(locationRegistration[chatId]).then((machineId) => {
                const messageId = locationRegistration[chatId].previewMessageId;
    
                bot.sendMessage(chatId, `Location added with ID: ${machineId}`).then(() => {
                    bot.deleteMessage(chatId, messageId);
                });
                delete locationRegistration[chatId]; // Clear registration data
            });
        } else if (data === 'LocationClose') {
            bot.deleteMessage(chatId, messageId).then(() => {
                delete locationRegistration[chatId];
            });
        }
    });
    
//view locations

 
async function getAllLocationsData( chatId) {  
  try {
 const machines = await getAllLocations();
 // console.log(machines);
 if (machines.length > 0) {
   const inlineKeyboard = machines.map(machine => {
     const statusMessage = `Status: ${machine.status === "1" ? "🟢" : "🔴"}`;

     return [{ 
       text: statusMessage + " " + machine.LocationName + "    " + machine.LocationShortCode, 
       callback_data: `viewLocation_${machine.id}` 
     }];
   });

   // Add the "Close" button at the end of the inline keyboard
   inlineKeyboard.push([{ text: 'Close', callback_data: 'close' }]);

   bot.sendMessage(chatId, 'Select a machine to view details:', {
     reply_markup: {
       inline_keyboard: inlineKeyboard,
     },
   });
 } else {
   bot.sendMessage(chatId, 'No machines found.');
 }
} catch (error) {
 console.error('Error fetching admins:', error);
 bot.sendMessage(chatId, 'An error occurred while fetching admins.');
}}

bot.onText(/View Locations/, async (msg) => {
  const chatId = msg.chat.id
  if(chatId === adminId){

  await getAllLocationsData(chatId)
  }
  
  });
  bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const messageId = callbackQuery.message.message_id;

    if(data === 'LocationBack'){
      bot.deleteMessage(chatId, messageId).then(()=>{
        getAllLocationsData(chatId)

      })
    }

    if (data.startsWith('viewLocation_')) {
      const machineId = data.split('_')[1];
  
      try {
        const machine = await getLocationById(machineId);
        if (machine) {
          
          displayLocationDetailsWithEditOptions(chatId, machine);
          bot.deleteMessage(chatId,messageId)
        } else {
          bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
        }
      } catch (error) {
        console.error('Error fetching machine details:', error);
        bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
      }
    }
  
    // Handle edits
    else if (data.startsWith('LocationUpdate_')) {
      const [action, adminId] = data.split('_').slice(1);
      const fieldMap = {
        LocationName: "LocationName",
        LocationShortCode:"LocationShortCode",
       
        

      };
      bot.deleteMessage(chatId, messageId).then(()=>{
        bot.sendMessage(chatId, `Please enter a new ${fieldMap[action]}:`, createCancelKeyboard());

      })

      
      bot.once('message', async (msg) => {
        const updatedValue = msg.text;
  
        // Here, you would update the technician's information in your database
        await updateLocationAttribute(adminId, action, updatedValue);
        
        bot.sendMessage(chatId, `${fieldMap[action]} updated successfully!`);
  
        // Optionally, redisplay the technician details after the update
         try {
            const technician = await getLocationById(adminId);
            if (technician) {
              displayLocationDetailsWithEditOptions(chatId, technician);
              // bot.deleteMessage(chatId,messageId)
            } else {
              bot.sendMessage(chatId, `Technician with ID ${adminId} not found.`);
            }
          } catch (error) {
            console.error('Error fetching technician details:', error);
            bot.sendMessage(chatId, 'An error occurred while fetching the technician details.');
          }
      });
    }
   
 
  });

  bot.on('callback_query', async (query) => {
    const callbackData = query.data; // Get the callback data
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    // Split the callback data
    const [action, machineId, status] = callbackData.split('_');

    if (action === 'ChangeLocationStatus') {
      bot.deleteMessage(chatId, messageId);
        // Function to create inline keyboard
        const createInlineKeyboard = (status) => {
            return {
                inline_keyboard: [
                    [
                        {
                            text: status === "1" ? '🟢 Make It Inactive' : '🔴 Make It Active',
                            callback_data: `buttonLocationActive_${machineId}_${status === "1" ? 0 : 1}`,
                        }
                    ]
                ]
            };
        };

        // Send a message asking to select status with inline keyboard
        await bot.sendMessage(chatId, `Please select status:`, {
            reply_markup: createInlineKeyboard(status),
        });

    } 
    else if (action === 'buttonLocationActive') {
        

        // Update the technician's status in the database
        await updateLocationStatus(machineId, status);
// Optionally, redisplay the technician details after the update
try {
    const machine = await getLocationById(machineId);
    if (machine) {
      displayLocationDetailsWithEditOptions(chatId, machine);
      
      bot.deleteMessage(chatId,messageId)
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
  } catch (error) {
    console.error('Error fetching machine details:', error);
    bot.sendMessage(chatId, 'An error occurred while fetching the machine details.');
  }
        // Notify the user
        await bot.sendMessage(chatId, `Status for machine has been changed to ${status}.`);
    }
    else if(action === 'deleteLocation'){
      const machine = await deleteLocationById(machineId);
    if (machine) {
      bot.deleteMessage(chatId, messageId).then(()=>{
  
      bot.sendMessage(chatId, `Machine with ID ${machineId} has been deleted.`);
      getAllLocationsData(chatId)
            
    })
    } else {
      bot.sendMessage(chatId, `machine with ID ${machineId} not found.`);
    }
    }
});


async function displayLocationDetailsWithEditOptions(chatId, machine) {
  const machineId = machine.id;
   const status = machine.status
   const statusMessage = `Status: ${status === "1" ? '🟢 Active' : '🔴 InActive'}`

  const message = `Updated Location Details:\n Location  Name: ${machine.LocationName} \n Location  Code:${machine.LocationShortCode} \n${statusMessage}`;
  
  const options = {
    reply_markup: {
      inline_keyboard: [
          [{ text: 'Edit Location Name', callback_data: `LocationUpdate_LocationName_${machineId}` },{ text: 'Edit Location Code', callback_data: `LocationUpdate_LocationShortCode_${machineId}` }],
 
          [{ text: 'Edit Status', callback_data: `ChangeLocationStatus_${machineId}_${status}` },{ text: 'Delete Location', callback_data: `deleteLocation_${machineId}` }],
          [{ text: 'Back', callback_data: 'LocationBack' }],

      ],
    },
  };
  
  return bot.sendMessage(chatId, message, options)
  .then(sentMessage => sentMessage.message_id);  // Return the messageId
    }


bot.on('polling_error', (error) => {
  console.log(error);  // Log polling errors
});



//generate machine 

// Function to get all technician data (mock implementation for demonstration)
async function getAllTechnicianData(chatId) {
  try {
      const admin = await getAllMachines(chatId);
      if (admin) {
          console.log(admin);
          return admin;
      }
      return false;
  } catch (error) {
      console.error('Error fetching technician:', error);
      await bot.sendMessage(chatId, 'There was an error checking your registration status.');
      return false;
  }
}

 
// Command to generate and send a PDF
bot.onText(/\/pdf/, async (msg) => {
  const chatId = msg.chat.id;
  const all = await getAllTechnicianData(chatId);

  if (!all) {
      await bot.sendMessage(chatId, 'No data found.');
      return;
  }

  // Format the fetched data for the PDF
  const formattedContent = all.map(item => {
      return `Machine Name: ${item.machineName}\nShort Code: ${item.machineShortCode}\nStatus: ${item.status ? "Active" : "Inactive"}\n\n`;
  }).join('');

  // Sample data to be included in the PDF
  const data = {
      title: 'Technician Data PDF',
      content: formattedContent,
      date: new Date().toLocaleString(),
  };


  

  // Create a PDF document
  const doc = new PDFDocument();
  const pdfPath = `./output-${chatId}.pdf`;

  // Pipe the document to a file
  const writeStream = fs.createWriteStream(pdfPath);
  doc.pipe(writeStream);

  // Add content to the PDF
  doc.fontSize(25).text(data.title, { align: 'center' });
  doc.moveDown();
  doc.fontSize(14).text(data.content);
  doc.moveDown();
  doc.fontSize(12).text(`Generated on: ${data.date}`, { align: 'right' });

  // Finalize the PDF and end the stream
  doc.end();

  // Wait for the file to be fully written to disk
  writeStream.on('finish', () => {
      // Send the PDF file to the user
      bot.sendDocument(chatId, pdfPath)
          .then(() => {
              // Delete the file after sending
              fs.unlinkSync(pdfPath);
              console.log('PDF sent and file deleted successfully.');
          })
          .catch((err) => {
              console.error('Error sending the PDF:', err);
          });
  });

  // Handle errors during file writing
  writeStream.on('error', (err) => {
      console.error('Error writing PDF to file:', err);
      bot.sendMessage(chatId, 'Failed to generate the PDF.');
  });


 
});

bot.onText(/\/getexcel/, async (msg) => {
  const chatId = msg.chat.id;
  const all = await getAllTechnicianData(chatId);

  if (!all) {
      await bot.sendMessage(chatId, 'No data found.');
      return;
  }



   // Create a new workbook and a worksheet
   const workbook = new ExcelJS.Workbook();
   const worksheet = workbook.addWorksheet('Machine Data');

   // Define columns for the worksheet
   worksheet.columns = [
       { header: 'Machine Name', key: 'machineName', width: 20 },
       { header: 'Short Code', key: 'machineShortCode', width: 15 },
       { header: 'Status', key: 'status', width: 10 },
       { header: 'Created At', key: 'created_at', width: 25 },
       { header: 'Updated At', key: 'updated_at', width: 25 },
   ];

   // Add rows to the worksheet
   all.forEach(item => {
       worksheet.addRow({
           machineName: item.machineName,
           machineShortCode: item.machineShortCode,
           status: item.status ? "Active" : "InActive",
           created_at: item.created_at,
           updated_at: item.updated_at
       });
   });

   const excelPath = `./output-${chatId}.xlsx`;

   // Write the workbook to a file
   await workbook.xlsx.writeFile(excelPath);

   // Send the Excel file to the user
   bot.sendDocument(chatId, excelPath)
       .then(() => {
           // Delete the file after sending
           fs.unlinkSync(excelPath);
           console.log('Excel file sent and deleted successfully.');
       })
       .catch((err) => {
           console.error('Error sending the Excel file:', err);
       });
});